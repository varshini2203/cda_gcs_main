import QtQuick 2.11
import QtQuick.Controls 2.4
import QtQuick.Layouts 1.11

// LoginScreen
// -----------
// Wide windows: blue brand panel on the left, white form on the right.
// Narrow windows: form only, with a small logo header.

Item {
    id: root

    signal accepted(string username)
    signal goToRegister()

    readonly property bool wide: width >= 760

    Rectangle {
        anchors.fill:   parent
        color:          AuthTheme.offWhite
    }

    Connections {
        target: AuthManager
        onLoginSucceeded: {
            errorLabel.text = ""
            root.accepted(username)
        }
        onLoginFailed: {
            errorLabel.text = reason
        }
    }

    Row {
        anchors.fill:   parent

        AuthBrandPanel {
            width:      parent.width * 0.42
            height:     parent.height
            visible:    root.wide
            tagline:    qsTr("New to drones or a seasoned pilot -\nyour missions pick up right where\nyou left them.")
        }

        Item {
            width:      root.wide ? parent.width * 0.58 : parent.width
            height:     parent.height

            Flickable {
                anchors.fill:   parent
                contentHeight:  form.height + 80
                contentWidth:   width

                Column {
                    id:                         form
                    anchors.horizontalCenter:   parent.horizontalCenter
                    anchors.top:                parent.top
                    anchors.topMargin:          Math.max(40, (parent.parent.height - form.height) / 2)
                    width:                      Math.min(parent.width * 0.82, 360)
                    spacing:                    18

                    // Compact logo header - shown only on narrow windows where
                    // the brand panel is hidden.
                    Row {
                        visible:            !root.wide
                        spacing:            10
                        anchors.horizontalCenter: parent.horizontalCenter

                        Image {
                            source:             "qrc:/qml/Auth/images/logo_mark.svg"
                            width:              36
                            height:             36
                            fillMode:           Image.PreserveAspectFit
                            sourceSize.width:   80
                        }

                        Text {
                            text:               qsTr("Chennai Drone Academy")
                            color:              AuthTheme.textDark
                            font.pixelSize:     16
                            font.bold:          true
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }

                    Column {
                        width:      parent.width
                        spacing:    4

                        Text {
                            text:               qsTr("Welcome back")
                            color:              AuthTheme.textDark
                            font.pixelSize:     26
                            font.bold:          true
                        }
                        Text {
                            text:               qsTr("Sign in to access your ground control station")
                            color:              AuthTheme.textMuted
                            font.pixelSize:     14
                            wrapMode:           Text.WordWrap
                            width:              parent.width
                        }
                    }

                    AuthTextField {
                        id:                 usernameField
                        width:              parent.width
                        label:              qsTr("Username")
                        placeholderText:    qsTr("Enter your username")
                    }

                    AuthTextField {
                        id:                 passwordField
                        width:              parent.width
                        label:              qsTr("Password")
                        placeholderText:    qsTr("Enter your password")
                        echoMode:           TextInput.Password
                        onAccepted:         loginButton.clicked()
                    }

                    Text {
                        id:                 errorLabel
                        width:              parent.width
                        wrapMode:           Text.WordWrap
                        color:              AuthTheme.errorRed
                        font.pixelSize:     13
                        visible:            text.length > 0
                    }

                    AuthButton {
                        id:                 loginButton
                        width:              parent.width
                        text:               qsTr("Log In")
                        onClicked:          AuthManager.login(usernameField.text, passwordField.text)
                    }

                    Row {
                        anchors.horizontalCenter:  parent.horizontalCenter
                        spacing:                   6

                        Text {
                            text:   qsTr("New here?")
                            color:  AuthTheme.textMuted
                            font.pixelSize: 14
                        }
                        Text {
                            text:               qsTr("Create an account")
                            color:              AuthTheme.brightBlue
                            font.pixelSize:     14
                            font.bold:          true

                            MouseArea {
                                anchors.fill:   parent
                                cursorShape:    Qt.PointingHandCursor
                                onClicked:      root.goToRegister()
                            }
                        }
                    }
                }
            }
        }
    }
}
