import QtQuick 2.11
import QtQuick.Controls 2.4
import QGroundControl 1.0
import QGroundControl.Palette 1.0

// SplashScreen
// ------------
// Branded first screen: blue gradient, academy logo, drone
// illustration, then routes to Home (if a session exists) or Login.

Item {
    id: root

    signal finished(bool alreadyLoggedIn)

    Rectangle {
        anchors.fill:   parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: AuthTheme.brightBlue }
            GradientStop { position: 1.0; color: AuthTheme.deepBlue }
        }
    }

    Image {
        id:                 hero
        source:             "qrc:/qml/Auth/images/drone_illustration.svg"
        anchors.centerIn:   parent
        anchors.verticalCenterOffset: parent.height * 0.06
        fillMode:           Image.PreserveAspectFit
        width:              Math.min(parent.width * 0.85, 520)
        sourceSize.width:   960
        opacity:            0.9
    }

    Column {
        id:                         brandColumn
        anchors.horizontalCenter:   parent.horizontalCenter
        anchors.top:                parent.top
        anchors.topMargin:          parent.height * 0.14
        spacing:                    14
        opacity:                    0
        scale:                      0.92

        Image {
            anchors.horizontalCenter:  parent.horizontalCenter
            source:                    "qrc:/qml/Auth/images/logo_mark_white.svg"
            width:                     84
            height:                    84
            fillMode:                  Image.PreserveAspectFit
            sourceSize.width:          200
        }

        Text {
            anchors.horizontalCenter:  parent.horizontalCenter
            text:                      qsTr("Chennai Drone Academy")
            color:                     AuthTheme.white
            font.pixelSize:            26
            font.bold:                 true
        }

        Text {
            anchors.horizontalCenter:  parent.horizontalCenter
            text:                      qsTr("GROUND CONTROL STATION")
            color:                     AuthTheme.textOnBlueMuted
            font.pixelSize:            13
            font.letterSpacing:        3
        }

        ParallelAnimation {
            running: true
            NumberAnimation { target: brandColumn; property: "opacity"; to: 1.0; duration: 550; easing.type: Easing.OutCubic }
            NumberAnimation { target: brandColumn; property: "scale";   to: 1.0; duration: 550; easing.type: Easing.OutCubic }
        }
    }

    BusyIndicator {
        anchors.horizontalCenter:  parent.horizontalCenter
        anchors.bottom:            parent.bottom
        anchors.bottomMargin:      parent.height * 0.10
        running:                   true

        // Tint the indicator white to sit on the blue background
        Component.onCompleted: {
            if (contentItem) contentItem.opacity = 0.9
        }
    }

    Timer {
        interval:   1400
        running:    true
        repeat:     false
        onTriggered: root.finished(AuthManager.isLoggedIn)
    }
}
