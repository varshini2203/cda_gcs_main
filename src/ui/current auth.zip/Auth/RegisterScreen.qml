import QtQuick 2.11
import QtQuick.Controls 2.4
import QtQuick.Layouts 1.11

// RegisterScreen
// --------------
// Mirrors LoginScreen's layout: blue brand panel on wide windows,
// white form card with the account-creation fields.

Item {
    id: root

    signal accepted(string username)
    signal goToLogin()

    readonly property bool wide: width >= 760

    Rectangle {
        anchors.fill:   parent
        color:          AuthTheme.offWhite
    }

    Connections {
        target: AuthManager
        onRegisterSucceeded: {
            errorLabel.text = ""
            root.accepted(username)
        }
        onRegisterFailed: {
            errorLabel.text = reason
        }
    }

    Row {
        anchors.fill:   parent

        AuthBrandPanel {
            width:      parent.width * 0.42
            height:     parent.height
            visible:    root.wide
            tagline:    qsTr("Join a growing fleet of certified\npilots training on real mission\nplanning tools.")
        }

        Item {
            width:      root.wide ? parent.width * 0.58 : parent.width
            height:     parent.height

            Flickable {
                anchors.fill:   parent
                contentHeight:  form.height + 80
                contentWidth:   width

                Column {
                    id:                         form
                    anchors.horizontalCenter:   parent.horizontalCenter
                    anchors.top:                parent.top
                    anchors.topMargin:          40
                    width:                      Math.min(parent.width * 0.82, 360)
                    spacing:                    18

                    Row {
                        visible:            !root.wide
                        spacing:            10
                        anchors.horizontalCenter: parent.horizontalCenter

                        Image {
                            source:             "qrc:/qml/Auth/images/logo_mark.svg"
                            width:              36
                            height:             36
                            fillMode:           Image.PreserveAspectFit
                            sourceSize.width:   80
                        }

                        Text {
                            text:               qsTr("Chennai Drone Academy")
                            color:              AuthTheme.textDark
                            font.pixelSize:     16
                            font.bold:          true
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }

                    Column {
                        width:      parent.width
                        spacing:    4

                        Text {
                            text:               qsTr("Create your account")
                            color:              AuthTheme.textDark
                            font.pixelSize:     26
                            font.bold:          true
                        }
                        Text {
                            text:               qsTr("Set up access to the ground control station")
                            color:              AuthTheme.textMuted
                            font.pixelSize:     14
                            wrapMode:           Text.WordWrap
                            width:              parent.width
                        }
                    }

                    AuthTextField {
                        id:                 usernameField
                        width:              parent.width
                        label:              qsTr("Username")
                        placeholderText:    qsTr("Choose a username")
                    }

                    AuthTextField {
                        id:                 passwordField
                        width:              parent.width
                        label:              qsTr("Password")
                        placeholderText:    qsTr("At least 4 characters")
                        echoMode:           TextInput.Password
                    }

                    AuthTextField {
                        id:                 confirmField
                        width:              parent.width
                        label:              qsTr("Confirm Password")
                        placeholderText:    qsTr("Re-enter password")
                        echoMode:           TextInput.Password
                        onAccepted:         registerButton.clicked()
                    }

                    Text {
                        id:                 errorLabel
                        width:              parent.width
                        wrapMode:           Text.WordWrap
                        color:              AuthTheme.errorRed
                        font.pixelSize:     13
                        visible:            text.length > 0
                    }

                    AuthButton {
                        id:                 registerButton
                        width:              parent.width
                        text:               qsTr("Register")
                        onClicked: {
                            AuthManager.registerUser(usernameField.text, passwordField.text, confirmField.text)
                        }
                    }

                    Row {
                        anchors.horizontalCenter:  parent.horizontalCenter
                        spacing:                   6

                        Text {
                            text:   qsTr("Already have an account?")
                            color:  AuthTheme.textMuted
                            font.pixelSize: 14
                        }
                        Text {
                            text:               qsTr("Log in")
                            color:              AuthTheme.brightBlue
                            font.pixelSize:     14
                            font.bold:          true

                            MouseArea {
                                anchors.fill:   parent
                                cursorShape:    Qt.PointingHandCursor
                                onClicked:      root.goToLogin()
                            }
                        }
                    }
                }
            }
        }
    }
}
